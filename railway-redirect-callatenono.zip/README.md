# Railway Redirect (callatenono.cl)

Redirecciona TODO el tráfico a una URL con un 302 temporal.
Úsalo como QR dinámico: el QR apunta a tu dominio y tú cambias `TARGET_URL` cuando quieras.

## Pasos rápidos
1) Sube estos archivos a Railway (GitHub o CLI).
2) En Variables agrega `TARGET_URL=https://www.instagram.com/callateenono` (o lo que quieras).
3) Añade tu dominio en Settings → Domains y configura los DNS en NIC.cl como indique Railway.
